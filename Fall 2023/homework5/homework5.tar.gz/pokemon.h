struct pokemon
{
    int level;
    char name[20];
};
