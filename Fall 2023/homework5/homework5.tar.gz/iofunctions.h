int writefile( struct pokemon pokearray[ ], int num, char filename[ ] );
int readfile( struct pokemon pokearray[ ], int* num, char filename[ ] );




